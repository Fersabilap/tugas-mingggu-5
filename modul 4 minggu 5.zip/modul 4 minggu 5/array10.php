<?php
$arrBuah = array ("Mangga", "Apel", "Pisang", "Kedondong", 
"Jeruk"); 
if (in_array ("Kedondong", $arrBuah)) { 
  echo "Ada buah Kedondong di sini"; 
 } else { 
  echo "Tidak ada buah Kedondong di sini"; 
}
?>
