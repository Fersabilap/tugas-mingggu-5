<?php
$arrBuah = array ("Mangga", "Apel", "Pisang", "Jeruk");
echo $arrBuah[0]; //Mangga 
echo $arrBuah[3]; //Jeruk 

$arrWarna = array(); 
$arrWarna[] = "Merah"; 
$arrWarna[] = "Biru";
$arrWarna[] = "Hijau"; 
$arrWarna[] = "Putih"; 
echo $arrWarna[0]; //Merah 
echo $arrWarna[2]; //Hijau
?> 
